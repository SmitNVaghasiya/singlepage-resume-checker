export { default as ResumeAnalysisUI } from "./ResumeAnalysisUI";
export { default as ViewDetailsUI2 } from "./view_DetailsUi_2";